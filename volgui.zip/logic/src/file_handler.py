import os

class FileHandler:
    def __init__(self):
        self.loaded_files = []
        self.selected_file = 0
        print(f"\nInitialized FileHandler with loaded_files: {self.loaded_files} and selected_file: {self.selected_file}\n")

    def remove_path(self, file_path, remove_extension=False):
        """
        Removes the path from a file path string.
        If remove_extension is True, also removes the file extension.
        
        Args:
            file_path (str): The file path to process.
            remove_extension (bool): Whether to remove the file extension. Default is False.
        
        Returns:
            str: The file name with or without extension.
        """
        file_name = os.path.basename(file_path)
        if remove_extension:
            file_name = os.path.splitext(file_name)[0]
        print(f"\nremove_path called with file_path: {file_path}, remove_extension: {remove_extension}. Result: {file_name}\n")
        return file_name

    def remove_file(self, index):
        """
        Removes the file path at the specified index from loaded_files.
        Also checks that selected_file is still a valid index.
        
        Args:
            index (int): The index of the file to remove.
        
        Raises:
            IndexError: If the index is out of range.
        """
        if 0 <= index < len(self.loaded_files):
            removed_file = self.loaded_files[index]
            del self.loaded_files[index]
            print(f"\nRemoved file at index {index}: {removed_file}. Updated loaded_files: {self.loaded_files}\n")
            # Adjust selected_file if necessary
            if self.selected_file >= len(self.loaded_files):
                self.selected_file = max(0, len(self.loaded_files) - 1)
                print(f"\nUpdated selected_file index to {self.selected_file}\n")
        else:
            print(f"\nAttempted to remove file at index {index}, which is out of range.\n")
            raise IndexError("Index out of range")

    def load_files(self, *file_paths):
        """
        Loads file paths into the loaded_files array.
        
        Args:
            file_paths (str): File paths to load.
        """
        self.loaded_files.extend(file_paths)
        if self.loaded_files:
            self.selected_file = 0  # Ensure the selected_file is set to the first loaded file
        print(f"\nLoaded files: {file_paths}. Updated loaded_files: {self.loaded_files}. Selected file: {self.get_selected_file()}\n")

    def get_selected_file(self):
        """
        Returns the currently selected file path.
        
        Returns:
            str: The selected file path.
        """
        selected_file = self.loaded_files[self.selected_file] if self.loaded_files else None
        print(f"\nget_selected_file called. Result: {selected_file}\n")
        return selected_file

    def get_loaded_files(self):
        """
        Returns the list of loaded file paths.
        
        Returns:
            list: The loaded file paths.
        """
        print(f"\nget_loaded_files called. Result: {self.loaded_files}\n")
        return self.loaded_files

# Example usage
if __name__ == "__main__":
    fh = FileHandler()
    fh.load_files("c:/files/somefile.png", "c:/files/anotherfile.png")
    print("\nLoaded files:", fh.get_loaded_files())
    print("\nSelected file:", fh.get_selected_file())
    print("\nRemoving path:", fh.remove_path(fh.get_selected_file()))
    fh.remove_file(0)
    print("\nLoaded files after removal:", fh.get_loaded_files())
    print("\nSelected file after removal:", fh.get_selected_file())
